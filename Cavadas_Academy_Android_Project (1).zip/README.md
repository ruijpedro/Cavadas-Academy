# Cavadas Academy

Versão preto/amarelo baseada na filosofia ChutaXuta + CAP Velha Guarda.

## Identidade visual
- Preto
- Amarelo neon
- Ícone oficial 2YOU Cavadas Academy

## Módulos
- Início
- Atletas
- Treinos
- Avaliação
- Pagamentos
- Vídeos / Animações
- Calendário
- Portal dos Pais
