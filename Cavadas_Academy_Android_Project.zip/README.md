# Cavadas Academy

App baseada na filosofia ChutaXuta + CAP Velha Guarda.

## Módulos
- Dashboard
- Atletas
- Treinos
- Avaliação
- Pagamentos
- Biblioteca de Vídeos/Animações
- Calendário
- Mais / Portal dos Pais

## Android
Package: `com.rjp.cavadasacademy`

## GitHub Actions
Executar: `Build Android APK`
