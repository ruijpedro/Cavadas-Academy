import React, { useMemo, useState } from 'react'
import { createRoot } from 'react-dom/client'
import {
  Home, Users, ClipboardCheck, Dumbbell, CreditCard, Video, CalendarDays, Menu,
  Trophy, CheckCircle2, AlertTriangle, Clock, Star, Plus, Search, Volleyball, Goal
} from 'lucide-react'
import './styles.css'

const modalities = ['Futsal', 'Futebol', 'Voleibol']

const athletes = [
  { name: 'Miguel Santos', modality: 'Futsal', team: 'Sub-13', pos: 'Ala', attendance: 94, eval: 4.6, pay: 'Pago' },
  { name: 'Tomás Ferreira', modality: 'Futebol', team: 'Sub-15', pos: 'Médio', attendance: 88, eval: 4.1, pay: 'Em atraso' },
  { name: 'Constança Rolim', modality: 'Voleibol', team: 'Sub-17', pos: 'Zona 4', attendance: 97, eval: 4.8, pay: 'Pago' },
  { name: 'Dinis Almeida', modality: 'Futsal', team: 'Sub-11', pos: 'Pivot', attendance: 81, eval: 3.9, pay: 'Pendente' }
]

const payments = [
  { athlete: 'Miguel Santos', type: 'Mensalidade Maio', value: '25€', status: 'Pago' },
  { athlete: 'Tomás Ferreira', type: 'Mensalidade Maio', value: '25€', status: 'Em atraso' },
  { athlete: 'Constança Rolim', type: 'Inscrição', value: '50€', status: 'Pago' },
  { athlete: 'Dinis Almeida', type: 'Equipamento', value: '35€', status: 'Pendente' }
]

const drills = [
  { title: 'Futsal — Saída 3+1', mod: 'Futsal', type: 'Tática', duration: '18 min', video: 'Vídeo + animação' },
  { title: 'Futebol — Receção orientada', mod: 'Futebol', type: 'Técnica', duration: '15 min', video: 'Vídeo' },
  { title: 'Voleibol — Manchete e deslocamento', mod: 'Voleibol', type: 'Técnica', duration: '20 min', video: 'Animação' },
  { title: 'Coordenação com escada', mod: 'Multi', type: 'Físico', duration: '12 min', video: 'Vídeo' }
]

function cx(status){
  if(status === 'Pago') return 'ok'
  if(status === 'Em atraso') return 'danger'
  return 'warn'
}

function App(){
  const tabs = [
    ['dashboard','Início',Home],
    ['atletas','Atletas',Users],
    ['treinos','Treinos',Dumbbell],
    ['avaliacao','Avaliação',ClipboardCheck],
    ['pagamentos','Pagamentos',CreditCard],
    ['videos','Vídeos',Video],
    ['calendario','Calendário',CalendarDays],
    ['mais','Mais',Menu],
  ]
  const [active,setActive] = useState('dashboard')
  const [modalidade,setModalidade] = useState('Futsal')
  const Page = useMemo(() => ({
    dashboard: Dashboard,
    atletas: Atletas,
    treinos: Treinos,
    avaliacao: Avaliacao,
    pagamentos: Pagamentos,
    videos: Videos,
    calendario: Calendario,
    mais: Mais
  })[active], [active])

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand">
        <img src="/icon-192.png" />
        <div>
          <h1>Cavadas Academy</h1>
          <p>Da Academia à Competição</p>
        </div>
      </div>
      <button className="notify"><AlertTriangle size={18}/><span>3</span></button>
    </header>

    <main className="content">
      <Page modalidade={modalidade} setModalidade={setModalidade}/>
    </main>

    <nav className="tabbar">
      {tabs.map(([id,label,Icon]) => <button key={id} onClick={()=>setActive(id)} className={active===id?'active':''}>
        <Icon size={20}/><span>{label}</span>
      </button>)}
    </nav>
  </div>
}

function SportFilter({modalidade,setModalidade}){
  return <div className="chips">
    {modalities.map(m => <button key={m} className={modalidade===m?'chip active':'chip'} onClick={()=>setModalidade(m)}>{m}</button>)}
  </div>
}

function Dashboard({modalidade,setModalidade}){
  return <section>
    <div className="hero">
      <div>
        <p className="eyebrow">Treino de hoje</p>
        <h2>{modalidade} — Sub-13</h2>
        <p className="muted"><Clock size={15}/> 19:00 · Pavilhão Municipal</p>
      </div>
      <div className="hero-score">
        <strong>16</strong>
        <span>confirmados</span>
      </div>
    </div>
    <SportFilter modalidade={modalidade} setModalidade={setModalidade}/>
    <div className="grid">
      <Metric icon={<Users/>} title="Atletas" value="128" note="3 modalidades"/>
      <Metric icon={<Dumbbell/>} title="Treinos" value="24" note="esta semana"/>
      <Metric icon={<CreditCard/>} title="Pagamentos" value="6" note="pendentes"/>
      <Metric icon={<Star/>} title="Avaliações" value="18" note="por fechar"/>
    </div>
    <Card title="Filosofia ChutaXuta + CAP">
      <p>App simples, rápida e visual: confirmações, gestão de atletas, pagamentos, avaliação e biblioteca de exercícios com vídeos/animações.</p>
    </Card>
    <Card title="Próximas ações">
      <Timeline items={['Marcar presenças do treino', 'Atualizar avaliação técnica', 'Adicionar vídeo ao exercício', 'Emitir relatório aos pais']}/>
    </Card>
  </section>
}

function Atletas(){
  return <section>
    <Title title="Atletas" subtitle="Ficha individual, modalidade, escalão, presenças e estado financeiro."/>
    <SearchBox/>
    {athletes.map((a,i)=><div className="athlete" key={a.name}>
      <div className="avatar">{a.name.split(' ').map(x=>x[0]).slice(0,2).join('')}</div>
      <div className="athlete-main">
        <strong>{a.name}</strong>
        <span>{a.modality} · {a.team} · {a.pos}</span>
        <div className="bar"><i style={{width:a.attendance+'%'}}></i></div>
      </div>
      <div className="athlete-side">
        <b>{a.eval}</b><small>avaliação</small>
        <em className={cx(a.pay)}>{a.pay}</em>
      </div>
    </div>)}
  </section>
}

function Treinos({modalidade,setModalidade}){
  return <section>
    <Title title="Gestão de Treino" subtitle="Planeamento de treino por modalidade e por atleta."/>
    <SportFilter modalidade={modalidade} setModalidade={setModalidade}/>
    <Card title={`${modalidade} — Sessão 01`}>
      <SessionLine name="Aquecimento técnico" time="10 min" tag="Bola + coordenação"/>
      <SessionLine name="Exercício principal" time="25 min" tag="Objetivo técnico/tático"/>
      <SessionLine name="Jogo condicionado" time="20 min" tag="Competição orientada"/>
      <SessionLine name="Retorno à calma" time="5 min" tag="Feedback"/>
      <button className="primary"><Plus size={18}/> Adicionar exercício</button>
    </Card>
    <Card title="Estado dos atletas">
      <div className="status-grid">
        <Pill label="Disponível" n="18" kind="ok"/>
        <Pill label="Condicionado" n="2" kind="warn"/>
        <Pill label="Lesionado" n="1" kind="danger"/>
      </div>
    </Card>
  </section>
}

function Avaliacao(){
  const rows = ['Técnica','Tática','Física','Mental/Comportamental']
  return <section>
    <Title title="Avaliação dos Atletas" subtitle="Notas de 1 a 5, evolução por período e relatório para pais."/>
    <Card title="Miguel Santos · Futsal Sub-13">
      {rows.map((r,i)=><EvalRow key={r} label={r} value={[92,84,78,96][i]} score={[4.6,4.2,3.9,4.8][i]}/>)}
      <textarea placeholder="Observações do treinador: atitude, pontos fortes, pontos a melhorar..."></textarea>
      <button className="primary">Gerar relatório PDF</button>
    </Card>
  </section>
}

function Pagamentos(){
  return <section>
    <Title title="Pagamentos" subtitle="Mensalidades, inscrições, equipamentos e eventos."/>
    <div className="grid two">
      <Metric icon={<CheckCircle2/>} title="Recebido" value="875€" note="este mês"/>
      <Metric icon={<AlertTriangle/>} title="Em falta" value="150€" note="6 atletas"/>
    </div>
    {payments.map(p => <div className="payment" key={p.athlete+p.type}>
      <div><strong>{p.athlete}</strong><span>{p.type}</span></div>
      <b>{p.value}</b>
      <em className={cx(p.status)}>{p.status}</em>
    </div>)}
  </section>
}

function Videos(){
  return <section>
    <Title title="Biblioteca de Exercícios" subtitle="Pasta de vídeos e animações para explicar exercícios."/>
    <div className="video-drop">
      <Video size={36}/>
      <strong>Adicionar vídeo/animação</strong>
      <span>Guardar por modalidade, objetivo, duração e material necessário.</span>
    </div>
    {drills.map(d => <div className="drill" key={d.title}>
      <div className="play">▶</div>
      <div><strong>{d.title}</strong><span>{d.type} · {d.duration} · {d.video}</span></div>
      <button>Usar no treino</button>
    </div>)}
  </section>
}

function Calendario(){
  return <section>
    <Title title="Calendário" subtitle="Treinos, jogos, torneios, reuniões e eventos."/>
    <Card title="Semana atual">
      <Timeline items={[
        'Segunda 19:00 — Futsal Sub-13',
        'Terça 18:30 — Futebol Sub-15',
        'Quarta 20:00 — Voleibol Sub-17',
        'Sábado 10:00 — Torneio / Jogo treino'
      ]}/>
    </Card>
  </section>
}

function Mais(){
  return <section>
    <Title title="Mais" subtitle="Configurações, pais, relatórios, Drive e exportações."/>
    {['Portal dos Pais','Exportar Excel/CSV','Relatórios PDF','Backup Google Drive','Definições da Academia'].map(x=>
      <div className="more" key={x}><span>{x}</span><b>›</b></div>
    )}
  </section>
}

function Metric({icon,title,value,note}){ return <div className="metric">{React.cloneElement(icon,{size:22})}<span>{title}</span><strong>{value}</strong><small>{note}</small></div> }
function Card({title,children}){ return <div className="card"><h3>{title}</h3>{children}</div> }
function Title({title,subtitle}){ return <div className="title"><h2>{title}</h2><p>{subtitle}</p></div> }
function SearchBox(){ return <div className="search"><Search size={18}/><input placeholder="Pesquisar atleta, escalão ou modalidade..." /></div> }
function Timeline({items}){ return <ul className="timeline">{items.map(i=><li key={i}>{i}</li>)}</ul> }
function SessionLine({name,time,tag}){ return <div className="session-line"><strong>{name}</strong><span>{tag}</span><b>{time}</b></div> }
function Pill({label,n,kind}){ return <div className={`pill ${kind}`}><strong>{n}</strong><span>{label}</span></div> }
function EvalRow({label,value,score}){ return <div className="eval-row"><div><strong>{label}</strong><span>{score}/5</span></div><div className="bar"><i style={{width:value+'%'}}></i></div></div> }

createRoot(document.getElementById('root')).render(<App />)
