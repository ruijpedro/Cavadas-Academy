import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Home, Users, Dumbbell, CalendarDays, Menu, CreditCard, Star, Video, Search, Plus, PlayCircle, ChevronRight, Bell, ClipboardCheck, Trophy, Volleyball, Goal } from 'lucide-react';
import './styles.css';

const athletes = [
  { name: 'Miguel Santos', age: 'Sub-13', sport: 'Futsal', position: 'Ala', attendance: 85, status: 'Ativo' },
  { name: 'Tiago Pereira', age: 'Sub-13', sport: 'Futebol', position: 'Médio', attendance: 92, status: 'Ativo' },
  { name: 'Guilherme Costa', age: 'Sub-15', sport: 'Futebol', position: 'Defesa', attendance: 78, status: 'Condicionado' },
  { name: 'João Oliveira', age: 'Sub-17', sport: 'Voleibol', position: 'Ponta', attendance: 88, status: 'Ativo' },
  { name: 'Leonardo Martins', age: 'Sub-13', sport: 'Futsal', position: 'Pivot', attendance: 70, status: 'Atenção' },
];

const exercises = [
  { title: 'Posse de bola 4x2', sport: 'Futsal', type: 'Técnica', time: '15 min', desc: 'Circulação rápida, apoio e tomada de decisão.' },
  { title: 'Cruza e finaliza', sport: 'Futebol', type: 'Finalização', time: '20 min', desc: 'Ataque pelos corredores e finalização.' },
  { title: 'Jogo de apoios 3x1', sport: 'Futsal', type: 'Tática', time: '10 min', desc: 'Criação de linhas de passe.' },
  { title: 'Receção e manchete', sport: 'Voleibol', type: 'Técnica', time: '15 min', desc: 'Controlo orientado e deslocamento.' },
];

function App() {
  const [tab, setTab] = useState('dashboard');
  const [sport, setSport] = useState('Todos');
  const filtered = useMemo(() => sport === 'Todos' ? athletes : athletes.filter(a => a.sport === sport), [sport]);

  return <div className="phone-shell">
    <header className="topbar">
      <Menu size={22}/>
      <div>
        <strong>Cavadas Academy</strong>
        <span>Da Academia à Competição</span>
      </div>
      <Bell size={21}/>
    </header>

    <main className="content">
      {tab === 'dashboard' && <Dashboard />}
      {tab === 'athletes' && <Athletes sport={sport} setSport={setSport} athletes={filtered} />}
      {tab === 'training' && <Training />}
      {tab === 'calendar' && <Calendar />}
      {tab === 'more' && <More />}
    </main>

    <nav className="bottomnav">
      <button className={tab==='dashboard'?'active':''} onClick={()=>setTab('dashboard')}><Home size={20}/>Dashboard</button>
      <button className={tab==='athletes'?'active':''} onClick={()=>setTab('athletes')}><Users size={20}/>Atletas</button>
      <button className={tab==='training'?'active':''} onClick={()=>setTab('training')}><Dumbbell size={20}/>Treinos</button>
      <button className={tab==='calendar'?'active':''} onClick={()=>setTab('calendar')}><CalendarDays size={20}/>Calendário</button>
      <button className={tab==='more'?'active':''} onClick={()=>setTab('more')}><Menu size={20}/>Mais</button>
    </nav>
  </div>
}

function Dashboard(){
  return <section>
    <div className="hero-card">
      <div className="brandmark">CA</div>
      <div>
        <small>PRÓXIMO TREINO</small>
        <h2>Futsal — Sub-13</h2>
        <p>Terça-feira, 21 Maio · 19:00 - 20:30</p>
        <p>Pavilhão Municipal</p>
      </div>
    </div>
    <div className="stats-grid">
      <Stat icon={<Users/>} value="128" label="Atletas" />
      <Stat icon={<Dumbbell/>} value="24" label="Treinos/semana" />
      <Stat icon={<CreditCard/>} value="6" label="Pendentes" danger />
    </div>
    <h3>Resumo rápido</h3>
    <ListItem icon={<ClipboardCheck/>} label="Presenças hoje" value="18" />
    <ListItem icon={<Star/>} label="Avaliações pendentes" value="7" warn />
    <ListItem icon={<CreditCard/>} label="Mensalidades em atraso" value="6" danger />
    <ListItem icon={<Trophy/>} label="Eventos próximos" value="3" />
  </section>
}

function Stat({icon,value,label,danger}){return <div className="stat">{React.cloneElement(icon,{size:23})}<b>{value}</b><span className={danger?'danger':''}>{label}</span></div>}
function ListItem({icon,label,value,danger,warn}){return <div className="listitem"><span className="roundicon">{React.cloneElement(icon,{size:18})}</span><b>{label}</b><em className={danger?'danger':warn?'warn':''}>{value}</em><ChevronRight size={18}/></div>}

function Athletes({sport,setSport,athletes}){
 return <section>
  <div className="page-title"><h2>Atletas</h2><div><Search/><Plus/></div></div>
  <div className="chips">{['Todos','Futebol','Futsal','Voleibol'].map(s=><button key={s} className={sport===s?'active':''} onClick={()=>setSport(s)}>{s}</button>)}</div>
  <div className="cards-list">{athletes.map((a,i)=><div className="athlete" key={a.name}><div className="avatar">{a.name.split(' ').map(x=>x[0]).slice(0,2).join('')}</div><div><b>{a.name}</b><span>{a.age} · {a.sport}</span><small>{a.position} · {a.status}</small></div><div className="ring">{a.attendance}%</div></div>)}</div>
 </section>
}

function Training(){
 return <section>
   <h2>Treino</h2>
   <div className="tabs"><button className="active">Plano</button><button>Presenças</button><button>Avaliação</button></div>
   <div className="training-plan">
    {['Aquecimento com bola','Posse de bola 4x2','Finalização após apoio','Jogo condicionado 5x5','Alongamentos'].map((x,i)=><div className="step" key={x}><b>{i+1}</b><span>{x}</span><em>{[10,15,20,20,10][i]} min</em></div>)}
   </div>
   <button className="primary">Iniciar treino</button>
   <h3>Biblioteca de exercícios</h3>
   {exercises.map(e=><div className="exercise" key={e.title}><div className="thumb"><PlayCircle/></div><div><b>{e.title}</b><span>{e.sport} · {e.type}</span><small>{e.time} — {e.desc}</small></div></div>)}
 </section>
}

function Calendar(){return <section><h2>Calendário</h2><div className="calendar-card"><h3>Esta semana</h3><ListItem icon={<Goal/>} label="Treino Futsal Sub-13" value="Ter"/><ListItem icon={<Trophy/>} label="Jogo Futebol Sub-15" value="Sáb"/><ListItem icon={<Volleyball/>} label="Treino Voleibol Sub-17" value="Qui"/></div></section>}
function More(){return <section><h2>Mais</h2><ListItem icon={<CreditCard/>} label="Pagamentos" value="6" danger/><ListItem icon={<Star/>} label="Avaliação dos atletas" value="7" warn/><ListItem icon={<Video/>} label="Vídeos e animações" value="4"/><ListItem icon={<Users/>} label="Portal dos pais" value=""/></section>}

createRoot(document.getElementById('root')).render(<App />);
