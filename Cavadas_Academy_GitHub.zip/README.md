# Cavadas Academy

App de gestão de academia desportiva inspirada na filosofia ChutaXuta/CAP: simples, direta e pronta para evoluir.

## Módulos
- Dashboard
- Atletas
- Treinos
- Avaliações
- Pagamentos
- Biblioteca de Exercícios com vídeos/animações
- Calendário
- Mais

## Instalar
```bash
npm install
npm run dev
```

## Build Web
```bash
npm run build
```

## Android / APK
```bash
npm run android:init
npm run android:sync
```
Depois correr o workflow GitHub Actions `Build Android APK` ou abrir em Android Studio.
